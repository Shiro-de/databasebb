import schedule from 'node-schedule';

let resetJob; // simpan job schedule biar bisa di-cancel saat ganti jadwal

let handler = async (m, { conn, args, command }) => {
    if (!args[0]) throw `Gunakan:\n.${command} on 25/50 12\n.${command} off`;

    let isOn = args[0].toLowerCase() === 'on';
    let limits = args[1] ? args[1].split('/') : [];
    let freeLimit = limits[0] ? parseInt(limits[0]) : 25;
    let premiumLimit = limits[1] ? parseInt(limits[1]) : 50;
    let hour = args[2] ? parseInt(args[2]) : 12; // default jam 12 siang

    if (isOn) {
        if (isNaN(freeLimit) || isNaN(premiumLimit)) throw 'Format angka tidak valid. Gunakan contoh: 20/50';
        if (isNaN(hour) || hour < 0 || hour > 23) throw 'Jam tidak valid! Gunakan angka 0-23 (format 24 jam)';

        global.db.data.settings.autoresetlimit = { active: true, free: freeLimit, premium: premiumLimit, hour };

        // cancel job lama kalau ada
        if (resetJob) resetJob.cancel();

        // bikin job baru sesuai jam
        resetJob = schedule.scheduleJob(`0 ${hour} * * *`, async () => {
            if (!global.db.data.settings.autoresetlimit?.active) return;

            let { free, premium } = global.db.data.settings.autoresetlimit;
            Object.entries(global.db.data.users).forEach(([user, data]) => {
                if (data.premiumTime) {
                    if (data.limit < premium) data.limit = premium;
                } else {
                    if (data.limit < free) data.limit = free;
                }
            });

            let notification = `*BERHASIL RESET LIMIT OTOMATIS*\n> *LIMIT USER FREE:* ${free}\n> *LIMIT USER PREMIUM:* ${premium}\n> *JAM RESET:* ${hour}:00 WIB`;
            let channelId = global.info?.channel;

            if (channelId && typeof conn?.sendMessage === 'function') {
                conn.sendMessage(channelId, { text: notification });
            }
        });

        m.reply(`✅ *AutoresetLimit Diaktifkan!*\n> *User Free:* ${freeLimit}\n> *User Premium:* ${premiumLimit}\n> *Jam Reset:* ${hour}:00 WIB`);
    } else if (args[0].toLowerCase() === 'off') {
        global.db.data.settings.autoresetlimit = { active: false };
        if (resetJob) resetJob.cancel();
        m.reply('❌ *AutoresetLimit Dimatikan!*');
    } else {
        throw `Gunakan:\n.${command} on 20/50 12\n.${command} off`;
    }
};

handler.help = ['autoresetlimit'];
handler.tags = ['owner'];
handler.command = /^(arl|autoresetlimit)$/i;
handler.owner = true;
export default handler;