import { ttdl } from 'ruhend-scraper';

const handler = async (m, { conn, text, command, prefix }) => {
  if (!text) {
    return m.reply(`Masukkan link TikTok!\nContoh: ${prefix + command} https://vt.tiktok.com/ZSYfBvx5d/`);
  }

  if (text.includes('Postingan ini dibagikan via TikTok Lite.')) {
    return m.reply('Salin linknya saja, jangan yang dari TikTok Lite.');
  }

  try {
    m.reply('⏳ Tunggu sebentar, sedang memproses...');
    const {
      title,
      author,
      username,
      published,
      like,
      comment,
      share,
      views,
      bookmark,
      video,
      music
    } = await ttdl(text);

    let caption = `*TIKTOK DOWNLOADER*\n\n`;
    caption += `⭔ *Author:* ${author}\n`;
    caption += `⭔ *Username:* ${username}\n`;
    caption += `⭔ *Description:* ${title}\n`;
    caption += `⭔ *Published:* ${published}\n`;
    caption += `⭔ *Like:* ${like}\n`;
    caption += `⭔ *Comment:* ${comment}\n`;
    caption += `⭔ *Views:* ${views}\n`;
    caption += `⭔ *Bookmark:* ${bookmark}\n`;

    // Kirim video TikTok
    await conn.sendFile(m.chat, video, 'tiktok.mp4', caption, m);

    // Kirim audio sebagai voice note (PTT)
    if (music) {
      await conn.sendMessage(m.chat, {
        audio: { url: music },
        mimetype: 'audio/mpeg',
        ptt: true // <- ini yang membuat jadi voice note
      }, { quoted: m });
    }

  } catch (err) {
    console.error(err);
    m.reply('❌ Gagal mengambil data TikTok. Pastikan link yang diberikan valid.');
  }
};

handler.help = handler.command = ['tiktok', 'tt', 'ttdl', 'ttnowm', 'titit'];
handler.tags = ['downloader'];
handler.limit = true;
handler.group = false;
handler.private = false;
handler.premium = false;
handler.owner = false;
handler.admin = false;
handler.botAdmin = false;
handler.fail = null;

export default handler;