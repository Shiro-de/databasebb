let handler = async (m, { conn }) => {
let vcard = `BEGIN:VCARD
VERSION:3.0
FN:Shiro
ORG:Shiro
TITLE:Metatron Executioner of Michael
EMAIL;type=INTERNET: milicentmdd@gmail.com
TEL;type=CELL;waid=6285128000929:+6285128000929
ADR;type=WORK:;;2-chōme-7-5 Fuchūchō;Izumi;Osaka;594-0071;Japan
URL;type=WORK:https://www.instagram.com/
X-WA-BIZ-NAME:Shiro
X-WA-BIZ-DESCRIPTION:𝐓𝐡𝐞 𝐃𝐞𝐯𝐞𝐥𝐨𝐩𝐞𝐫 𝐎𝐟 𝐋𝐢𝐨𝐫𝐚
X-WA-BIZ-HOURS:Mo-Su 00:00-23:59
END:VCARD`
let qkontak = {
key: {
fromMe: false,
participant: "0@s.whatsapp.net",
remoteJid: "status@broadcast"
},
message: {
contactMessage: {
displayName: "Shiro",
vcard
}
}
}
await conn.sendMessage(m.chat, {
contacts: {
displayName: 'Shiro',
contacts: [{ vcard }]
},
contextInfo: {
externalAdReply: {
title: 'Copyright © 2024 - 2025 Liora',
body: 'Hubungi langsung lewat WhatsApp',
thumbnailUrl: 'https://cloudkuimages.guru/uploads/images/4cMqWuGp.jpg',
mediaType: 1,
renderLargerThumbnail: true
}
}
}, { quoted: qkontak })
}

handler.help = ['owner']
handler.tags = ['info']
handler.command = /^(owner|creator)$/i

export default handler